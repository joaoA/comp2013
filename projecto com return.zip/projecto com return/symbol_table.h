#ifndef _SYMBOL_TABLE_
#define _SYMBOL_TABLE_

typedef enum {integer, character, doub, bool, procedure,input_int, input_double, input_char} basic_type;

//lista ligada de simbolos - um ambiente/registo de activa��o
typedef struct _t1{	
	char name[32];
	int isArg;
	basic_type type;
	int offset;		//futura posi��o na frame, caso seja uma variavel -1, se for uma procedure.
	struct _t1 *next;
} table_element;


//lista de procedimentos definidos no programa
typedef struct _t4{
	char* name;
	struct _t4 *next;
	table_element *locals;
}environment_list;

//Estrutura que guarda TODOS os simbolos de um programa: o ambiente "global" e a lista de ambientes
typedef struct _t5{
	table_element* global;
	environment_list* procs;
}prog_env;
#endif
