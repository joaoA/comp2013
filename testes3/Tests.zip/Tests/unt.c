char **buffer[20];

int check();
int check();

int a ;
int b;
int a;
int **a;

int main(int argc, char **argv) {
	int a, b;
	a = atoi(argv[1]);
	b = atoi(argv[2]);
	if (a == 0) {
		printf(itoa(b, buffer));
		printf("\n");
	} else {
		while (b > 0)
			if (a > b)
				a = a-b;
			else
				b = b-a;
		printf(itoa(a, buffer));
		printf("\n");
		}
	return 0;
}

int main();

int check = 1;

int check(){
int ola;
return ola;
}

int check(){}

