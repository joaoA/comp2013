int main(){
	0;
	0;
	123;
	return 0;
}
