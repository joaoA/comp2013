int a;
int *b;
int c;
char **d;
char e;
char **f,*g,h;
int a,**b,***c,*d;
int **a[2];
int a[2];
char **b[3];
char b[1];
int f();
char v();
int *f();
int **f();
char *v();
char **v();
int f(int a,char b,int *a,int **a,char *b);
char v(int a,char b,int *a,int **a,char *b);
int *f(int a,char b,int *a,int **a,char *b);
int **f(int a,char b,int *a,int **a,char *b);
char *v(int a,char b,int *a,int **a,char *b);
char **v(int a,char b,int *a,int **a,char *b);

int f(int a,char b){
	int *a;
	char *b[2];
}

char v(char *v,int **a){
	int b[2];
	char **v;
}
