#include "structures.h"

void add_space(int n);
void show_program(is_node * program, int ident);
void show_expression(is_node * no, int ident);
